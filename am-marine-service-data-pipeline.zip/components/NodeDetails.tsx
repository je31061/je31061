
import React from 'react';
import { PipelineNode } from '../types';

interface NodeDetailsProps {
  node: PipelineNode | null;
  onClose: () => void;
}

const NodeDetails: React.FC<NodeDetailsProps> = ({ node, onClose }) => {
  if (!node) return null;

  return (
    <div className="fixed top-20 right-6 w-80 bg-white shadow-2xl rounded-xl border border-slate-200 overflow-hidden z-50">
      <div className="bg-slate-900 px-4 py-3 flex justify-between items-center">
        <h3 className="text-white font-semibold text-sm">상세 정보</h3>
        <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      <div className="p-5">
        <div className="mb-4">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">단계명</span>
          <h2 className="text-xl font-bold text-slate-800 leading-tight">{node.label}</h2>
        </div>
        
        {node.description && (
          <div className="mb-4">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">설명</span>
            <p className="text-sm text-slate-600 mt-1">{node.description}</p>
          </div>
        )}

        {node.details && node.details.length > 0 && (
          <div className="mb-4">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">주요 업무 / 등록 데이터</span>
            <ul className="mt-2 space-y-2">
              {node.details.map((detail, idx) => (
                <li key={idx} className="flex items-start text-sm text-slate-600">
                  <span className="text-blue-500 mr-2 font-bold">•</span>
                  <span>{detail}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="pt-4 border-t border-slate-100 mt-4 flex justify-between items-center">
          <div className="px-2 py-1 rounded bg-slate-100 text-[10px] font-bold text-slate-500 uppercase tracking-tighter">
            {node.type}
          </div>
          <div className="text-[10px] text-slate-400">ID: {node.id}</div>
        </div>
      </div>
    </div>
  );
};

export default NodeDetails;
