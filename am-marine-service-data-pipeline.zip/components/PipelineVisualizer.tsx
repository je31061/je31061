
import React, { useState, useMemo, useEffect } from 'react';
import { Department, PipelineNode, PipelineEdge } from '../types';
import { WORKFLOWS } from '../constants';

interface PipelineVisualizerProps {
  department: Department;
}

const PipelineVisualizer: React.FC<PipelineVisualizerProps> = ({ department }) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
  const data = useMemo(() => WORKFLOWS[department], [department]);

  // Calculate center points for easier rendering
  const getPath = (edge: PipelineEdge) => {
    const fromNode = data.nodes.find(n => n.id === edge.from);
    const toNode = data.nodes.find(n => n.id === edge.to);

    if (!fromNode || !toNode) return "";

    const startX = fromNode.x + 160; // Right side of node
    const startY = fromNode.y + 30;  // Middle height of node
    const endX = toNode.x;           // Left side of node
    const endY = toNode.y + 30;      // Middle height of node

    const cp1x = startX + (endX - startX) / 2;
    const cp2x = startX + (endX - startX) / 2;
    
    return `M ${startX} ${startY} C ${cp1x} ${startY}, ${cp2x} ${endY}, ${endX} ${endY}`;
  };

  const renderEdge = (edge: PipelineEdge, index: number) => {
    const path = getPath(edge);
    if (!path) return null;

    const isConnectedToSelected = selectedNodeId === edge.from || selectedNodeId === edge.to;
    const isConnectedToHovered = hoveredNodeId === edge.from || hoveredNodeId === edge.to;
    const isActive = isConnectedToSelected || isConnectedToHovered;

    return (
      <g key={`${edge.from}-${edge.to}-${index}`}>
        {/* Background Path */}
        <path
          d={path}
          stroke={isActive ? "#93c5fd" : "#e2e8f0"}
          strokeWidth={isActive ? "3" : "2"}
          fill="none"
          className="transition-all duration-300"
        />
        
        {/* Animated Stream */}
        <path
          d={path}
          stroke={isActive ? "#3b82f6" : "#cbd5e1"}
          strokeWidth={isActive ? "3" : "1.5"}
          fill="none"
          strokeDasharray="4,8"
          className="animate-flow"
          style={{ animationDuration: isActive ? '0.8s' : '1.5s' }}
        />

        {/* Moving Particles (The "Data Stream" effect) */}
        {edge.isAnimated && (
          <>
            {[0, 1, 2].map((i) => (
              <circle key={i} r="2.5" fill="#3b82f6" className="data-glow">
                <animateMotion
                  path={path}
                  dur={`${2.5 + i * 0.5}s`}
                  repeatCount="indefinite"
                  begin={`${i * 0.8}s`}
                />
              </circle>
            ))}
          </>
        )}

        {edge.label && (
          <g>
            <rect
              x={(data.nodes.find(n => n.id === edge.from)?.x || 0) + 160 + ( (data.nodes.find(n => n.id === edge.to)?.x || 0) - (data.nodes.find(n => n.id === edge.from)?.x || 0) - 160) / 2 - 25}
              y={((data.nodes.find(n => n.id === edge.from)?.y || 0) + (data.nodes.find(n => n.id === edge.to)?.y || 0)) / 2 + 22}
              width="50"
              height="16"
              rx="8"
              fill="white"
              stroke="#e2e8f0"
            />
            <text
              x={(data.nodes.find(n => n.id === edge.from)?.x || 0) + 160 + ( (data.nodes.find(n => n.id === edge.to)?.x || 0) - (data.nodes.find(n => n.id === edge.from)?.x || 0) - 160) / 2}
              y={((data.nodes.find(n => n.id === edge.from)?.y || 0) + (data.nodes.find(n => n.id === edge.to)?.y || 0)) / 2 + 34}
              textAnchor="middle"
              className="text-[9px] font-bold fill-slate-500 uppercase italic pointer-events-none"
            >
              {edge.label}
            </text>
          </g>
        )}
      </g>
    );
  };

  const renderNode = (node: PipelineNode) => {
    const isSelected = selectedNodeId === node.id;
    const isHovered = hoveredNodeId === node.id;
    
    let accentColor = 'blue';
    let iconPath = null;

    switch (node.type) {
      case 'input': accentColor = 'emerald'; break;
      case 'output': accentColor = 'amber'; break;
      case 'decision': accentColor = 'indigo'; break;
      case 'system': accentColor = 'cyan'; break;
      case 'process': accentColor = 'blue'; break;
    }

    const colors = {
      blue: 'border-blue-200 bg-blue-50 text-blue-700',
      emerald: 'border-emerald-200 bg-emerald-50 text-emerald-700',
      amber: 'border-amber-200 bg-amber-50 text-amber-700',
      indigo: 'border-indigo-200 bg-indigo-50 text-indigo-700',
      cyan: 'border-cyan-200 bg-cyan-50 text-cyan-700',
    }[accentColor];

    const activeBorders = {
      blue: 'border-blue-500 ring-blue-100',
      emerald: 'border-emerald-500 ring-emerald-100',
      amber: 'border-amber-500 ring-amber-100',
      indigo: 'border-indigo-500 ring-indigo-100',
      cyan: 'border-cyan-500 ring-cyan-100',
    }[accentColor];

    return (
      <foreignObject
        key={node.id}
        x={node.x}
        y={node.y}
        width="160"
        height="60"
        className="overflow-visible"
        onMouseEnter={() => setHoveredNodeId(node.id)}
        onMouseLeave={() => setHoveredNodeId(null)}
      >
        <div
          onClick={() => setSelectedNodeId(node.id === selectedNodeId ? null : node.id)}
          className={`
            w-full h-full rounded-xl border-2 shadow-sm transition-all duration-300 cursor-pointer flex flex-col justify-center px-4 relative
            ${colors}
            ${isSelected || isHovered ? `scale-105 shadow-md ${activeBorders} ring-4` : 'hover:shadow-md'}
          `}
        >
          {/* Status Dot */}
          <div className={`absolute top-2 right-2 w-2 h-2 rounded-full ${isSelected || isHovered ? 'bg-blue-500 animate-pulse' : 'bg-slate-300'}`}></div>
          
          <span className="text-[8px] font-black uppercase tracking-tighter opacity-60 mb-1">
            {node.type}
          </span>
          <span className="text-[11px] font-bold leading-tight line-clamp-2">
            {node.label}
          </span>
        </div>
      </foreignObject>
    );
  };

  const selectedNode = data.nodes.find(n => n.id === selectedNodeId) || null;

  return (
    <div className="relative w-full h-[650px] bg-white rounded-2xl overflow-hidden group">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
      
      <div className="absolute top-6 left-8 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center shadow-lg">
             <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-800 tracking-tight">Data Stream Visualization</h2>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">{department}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Real-time Node Monitoring</span>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full h-full overflow-auto cursor-grab active:cursor-grabbing p-12 custom-scrollbar">
        <svg 
          viewBox="0 0 1400 350" 
          width="1400" 
          height="350"
          className="mx-auto"
        >
          <g transform="translate(0, 50)">
            {data.edges.map((edge, i) => renderEdge(edge, i))}
            {data.nodes.map(renderNode)}
          </g>
        </svg>
      </div>

      {/* Info Panel Overlay */}
      <div className={`
        absolute bottom-0 inset-x-0 bg-slate-900 text-white p-8 transform transition-transform duration-500 ease-out z-20 border-t border-slate-700
        ${selectedNode ? 'translate-y-0' : 'translate-y-full'}
      `}>
        {selectedNode && (
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-8 items-start">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-400 text-[10px] font-black uppercase tracking-widest border border-blue-500/30">
                  {selectedNode.type}
                </span>
                <span className="text-[10px] font-mono text-slate-500">Node ID: {selectedNode.id}</span>
              </div>
              <h3 className="text-3xl font-black mb-2 tracking-tight">{selectedNode.label}</h3>
              <p className="text-slate-400 text-sm leading-relaxed max-w-lg">
                {selectedNode.description || `${selectedNode.label} 단계에서는 부서 내 정의된 프로토콜에 따라 해당 데이터를 처리하고 다음 파이프라인으로 전달합니다.`}
              </p>
            </div>

            <div className="flex-[1.5] grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
              {selectedNode.details ? (
                selectedNode.details.map((d, i) => (
                  <div key={i} className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/10 hover:bg-white/10 transition-colors group/item">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-400 font-bold text-xs group-hover/item:bg-blue-500 group-hover/item:text-white transition-all">
                      {i + 1}
                    </div>
                    <span className="text-sm font-medium text-slate-200">{d}</span>
                  </div>
                ))
              ) : (
                <div className="col-span-2 py-8 flex items-center justify-center border-2 border-dashed border-white/10 rounded-2xl">
                   <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">No detailed sub-tasks registered</p>
                </div>
              )}
            </div>

            <button 
              onClick={() => setSelectedNodeId(null)}
              className="absolute top-6 right-6 p-2 rounded-full hover:bg-white/10 transition-colors text-slate-400 hover:text-white"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        )}
      </div>

      {/* Control Legend */}
      <div className="absolute top-6 right-8 flex gap-3">
        {['Input', 'System', 'Process', 'Decision', 'Output'].map((t) => (
          <div key={t} className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-50 border border-slate-200">
             <div className={`w-2 h-2 rounded-full ${
               t === 'Input' ? 'bg-emerald-400' : 
               t === 'System' ? 'bg-cyan-400' :
               t === 'Process' ? 'bg-blue-400' :
               t === 'Decision' ? 'bg-indigo-400' : 'bg-amber-400'
             }`}></div>
             <span className="text-[9px] font-bold text-slate-500 uppercase">{t}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PipelineVisualizer;
