
export enum Department {
  MARINE_SERVICE = '마린서비스팀',
  DEVELOPMENT = 'AM개발팀',
  SPARE_SALES = '스페어팀(영업/관리)',
  SPARE_LOGISTICS = '스페어팀(납품)',
  OPERATION_INNOVATION = 'AM운영혁신팀'
}

export interface PipelineNode {
  id: string;
  label: string;
  description?: string;
  details?: string[];
  department: Department;
  type: 'process' | 'decision' | 'input' | 'output' | 'system';
  x: number;
  y: number;
}

export interface PipelineEdge {
  from: string;
  to: string;
  label?: string;
  isAnimated?: boolean;
}

export interface WorkflowData {
  nodes: PipelineNode[];
  edges: PipelineEdge[];
}
