
import React, { useState, useEffect } from 'react';
import { Department } from './types';
import PipelineVisualizer from './components/PipelineVisualizer';

const App: React.FC = () => {
  const [activeDept, setActiveDept] = useState<Department>(Department.MARINE_SERVICE);
  const [logs, setLogs] = useState<{id: number, time: string, msg: string, type: string}[]>([]);

  useEffect(() => {
    // Simulate real-time data stream logs
    const interval = setInterval(() => {
      const messages = [
        "Data Packet #PX-920 routing through ERP...",
        "Validating Spare BOM compatibility...",
        "Syncing logistics manifest with Global Fleet...",
        "New Claim request detected in CHS Queue",
        "Updating Inventory levels for Spare Parts",
        "Optimizing MRO engineer schedules..."
      ];
      const types = ['info', 'success', 'warning', 'process'];
      const newLog = {
        id: Date.now(),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        msg: messages[Math.floor(Math.random() * messages.length)],
        type: types[Math.floor(Math.random() * types.length)]
      };
      setLogs(prev => [newLog, ...prev].slice(0, 10));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const stats = [
    { label: 'Active Streams', value: '24', change: '+3', trend: 'up' },
    { label: 'Node Latency', value: '18ms', change: '-2ms', trend: 'down' },
    { label: 'Data Integrity', value: '100%', change: 'Stable', trend: 'stable' },
    { label: 'System Uptime', value: '99.9%', change: '+0.1%', trend: 'up' }
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Dynamic Background */}
      <div className="fixed inset-0 -z-10 bg-slate-50"></div>

      {/* Main Command Header */}
      <header className="bg-white/70 backdrop-blur-xl border-b border-slate-200/60 px-8 py-5 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-6">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <div className="relative bg-slate-900 p-2.5 rounded-xl border border-slate-800 shadow-xl">
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tighter uppercase leading-none">AM Stream Control</h1>
            <div className="flex items-center gap-2 mt-1">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase">Marine Service Data Hub</p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-8">
          <nav className="hidden lg:flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200">
            {Object.values(Department).map((dept) => (
              <button
                key={dept}
                onClick={() => setActiveDept(dept)}
                className={`
                  px-4 py-2 rounded-lg text-xs font-black transition-all duration-300
                  ${activeDept === dept 
                    ? 'bg-white text-blue-600 shadow-md ring-1 ring-slate-200/50' 
                    : 'text-slate-400 hover:text-slate-600 hover:bg-slate-200/50'}
                `}
              >
                {dept}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4 border-l pl-8 border-slate-200">
            <div className="text-right">
              <p className="text-[10px] font-bold text-slate-400 uppercase leading-none">Global Server</p>
              <p className="text-xs font-black text-slate-700">KR-HQ-01</p>
            </div>
            <button className="bg-slate-900 text-white p-2.5 rounded-xl hover:bg-slate-800 transition-all shadow-lg hover:scale-105 active:scale-95">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 p-8 max-w-[1600px] mx-auto w-full">
        {/* Stat Pulse Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
           {stats.map((stat, i) => (
             <div key={i} className="group bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-500 overflow-hidden relative">
                <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                  <svg className="w-20 h-20" fill="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                </div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">{stat.label}</p>
                <div className="flex items-end justify-between relative z-10">
                  <span className="text-3xl font-black text-slate-900 tracking-tighter">{stat.value}</span>
                  <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black ${
                    stat.trend === 'up' ? 'bg-emerald-50 text-emerald-600' : 
                    stat.trend === 'down' ? 'bg-rose-50 text-rose-600' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {stat.trend === 'up' && <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg>}
                    {stat.trend === 'down' && <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 14l-7 7m0 0l-7-7m7 7V3" /></svg>}
                    {stat.change}
                  </div>
                </div>
             </div>
           ))}
        </div>

        {/* Visualizer Container */}
        <div className="bg-slate-900 p-1 rounded-[2.5rem] shadow-2xl border border-slate-800 mb-8 overflow-hidden group/vis">
           <div className="bg-white rounded-[2.25rem] overflow-hidden">
             <PipelineVisualizer department={activeDept} />
           </div>
        </div>

        {/* Console & Activity Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[400px]">
          {/* Real-time Stream Console */}
          <div className="lg:col-span-2 bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50 backdrop-blur">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                <h3 className="text-xs font-black text-white uppercase tracking-widest">Live Stream Log</h3>
              </div>
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
              </div>
            </div>
            <div className="flex-1 p-6 font-mono text-[11px] overflow-y-auto space-y-2 custom-scrollbar">
              {logs.map((log) => (
                <div key={log.id} className="flex gap-4 animate-in fade-in slide-in-from-left-2">
                  <span className="text-slate-600 shrink-0">[{log.time}]</span>
                  <span className="text-blue-500 shrink-0">SYS_STREAM:</span>
                  <span className={`
                    ${log.type === 'success' ? 'text-emerald-400' : 
                      log.type === 'warning' ? 'text-amber-400' : 
                      log.type === 'process' ? 'text-cyan-400' : 'text-slate-300'}
                  `}>
                    {log.msg}
                  </span>
                </div>
              ))}
              <div className="flex gap-4 items-center">
                 <span className="text-slate-600">[{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}]</span>
                 <span className="text-blue-500">CURSOR_IDLE</span>
                 <span className="w-2 h-4 bg-blue-500 animate-pulse"></span>
              </div>
            </div>
          </div>

          {/* Department Status Card */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 flex flex-col">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">Department Health</h3>
            <div className="space-y-6 flex-1">
              {Object.values(Department).slice(0, 4).map((dept, i) => (
                <div key={i} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-700">{dept}</span>
                    <span className="text-[10px] font-black text-blue-600">Active</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full transition-all duration-1000" style={{ width: `${85 + Math.random() * 15}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
            <div className="pt-6 border-t border-slate-100 mt-auto">
               <button className="w-full py-3 bg-slate-50 text-slate-600 text-xs font-black uppercase tracking-widest rounded-xl hover:bg-slate-100 transition-colors">
                  System Diagnostics
               </button>
            </div>
          </div>
        </div>
      </main>

      <footer className="px-8 py-6 flex justify-between items-center bg-white border-t border-slate-200">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">
          © 2024 AM Marine Division — Operational Stream Platform
        </p>
        <div className="flex gap-6">
          <span className="text-[10px] font-black text-slate-300 uppercase italic">Confidential</span>
          <span className="text-[10px] font-black text-slate-300 uppercase italic">Authorized Personnel Only</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
