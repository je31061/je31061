
import { Department, WorkflowData } from './types';

export const WORKFLOWS: Record<Department, WorkflowData> = {
  [Department.MARINE_SERVICE]: {
    nodes: [
      { id: 'cl_1', label: '클레임 접수', type: 'input', x: 50, y: 100, department: Department.MARINE_SERVICE, description: 'AS 요청 접수 (Warranty, 유상, 문의)' },
      { id: 'cl_2', label: 'ERP 확인', type: 'system', x: 250, y: 100, department: Department.MARINE_SERVICE, details: ['수주번호 확인', '보증기간 확인', 'Owner Benefit'] },
      { id: 'cl_3', label: 'CHS 등록', type: 'system', x: 450, y: 100, department: Department.MARINE_SERVICE, details: ['선명/분류', 'Claim 내용', 'Email 파일', '담당자 지정'] },
      { id: 'cl_dec', label: '조치 경로 선택', type: 'decision', x: 650, y: 100, department: Department.MARINE_SERVICE },
      { id: 'path_ts', label: 'Trouble Shooting', type: 'process', x: 850, y: 20, department: Department.MARINE_SERVICE, details: ['T/S Manual 확인', '도면 준비', '조치방안 회신'] },
      { id: 'path_mat', label: '자재 공급', type: 'process', x: 850, y: 100, department: Department.MARINE_SERVICE, details: ['Maker 공급요청', '자재출고', '자재탁송'] },
      { id: 'path_se', label: 'S/E 방선', type: 'process', x: 850, y: 180, department: Department.MARINE_SERVICE, details: ['출장 일정 수립', '비자/허가 준비', '방선 점검'] },
      { id: 'cl_fin', label: '결과 등록 & 정산', type: 'output', x: 1100, y: 100, department: Department.MARINE_SERVICE, details: ['서비스레포트', '유상 견적서 제출', '인보이스 전달'] },
    ],
    edges: [
      { from: 'cl_1', to: 'cl_2', isAnimated: true },
      { from: 'cl_2', to: 'cl_3', isAnimated: true },
      { from: 'cl_3', to: 'cl_dec', isAnimated: true },
      { from: 'cl_dec', to: 'path_ts', label: 'T/S' },
      { from: 'cl_dec', to: 'path_mat', label: '자재' },
      { from: 'cl_dec', to: 'path_se', label: '방선' },
      { from: 'path_ts', to: 'cl_fin' },
      { from: 'path_mat', to: 'cl_fin' },
      { from: 'path_se', to: 'cl_fin' },
    ]
  },
  [Department.DEVELOPMENT]: {
    nodes: [
      { id: 'dev_1', label: '수주별 Spare BOM 등록', type: 'input', x: 50, y: 100, department: Department.DEVELOPMENT },
      { id: 'dev_2', label: 'Master BOM 요청', type: 'process', x: 250, y: 100, department: Department.DEVELOPMENT, details: ['구매팀 Excel 요청'] },
      { id: 'dev_3', label: '도면/자료 확인', type: 'process', x: 450, y: 100, department: Department.DEVELOPMENT, details: ['최종 도면 PDF 다운로드'] },
      { id: 'dev_4', label: 'BOM 제작 & 업로드', type: 'system', x: 650, y: 100, department: Department.DEVELOPMENT, details: ['SPARE BOM 엑셀 제작', 'ERP 업로드'] },
      { id: 'dev_5', label: '정찰가 체크/등록', type: 'output', x: 850, y: 100, department: Department.DEVELOPMENT, details: ['사진/도면 추가', '판매가 등록 현황 확인'] },
    ],
    edges: [
      { from: 'dev_1', to: 'dev_2', isAnimated: true },
      { from: 'dev_2', to: 'dev_3', isAnimated: true },
      { from: 'dev_3', to: 'dev_4', isAnimated: true },
      { from: 'dev_4', to: 'dev_5', isAnimated: true },
    ]
  },
  [Department.SPARE_SALES]: {
    nodes: [
      { id: 'ss_1', label: '견적 의뢰 접수', type: 'input', x: 50, y: 50, department: Department.SPARE_SALES },
      { id: 'ss_2', label: '문의서 검토', type: 'process', x: 200, y: 50, department: Department.SPARE_SALES },
      { id: 'ss_dec1', label: '견적 가능?', type: 'decision', x: 350, y: 50, department: Department.SPARE_SALES },
      { id: 'ss_3', label: 'STOCK 확인', type: 'system', x: 500, y: 50, department: Department.SPARE_SALES, details: ['ERP 재고 조회', '기실적 참조'] },
      { id: 'ss_4', label: '견적서 작성/제출', type: 'output', x: 700, y: 50, department: Department.SPARE_SALES },
      { id: 'ss_5', label: '발주서 접수', type: 'input', x: 50, y: 180, department: Department.SPARE_SALES },
      { id: 'ss_6', label: '수주 상세 등록', type: 'system', x: 250, y: 180, department: Department.SPARE_SALES, details: ['품명/수량/단가 ERP 입력'] },
      { id: 'ss_7', label: '수주 확정', type: 'process', x: 450, y: 180, department: Department.SPARE_SALES },
      { id: 'ss_8', label: '인보이스/수금', type: 'output', x: 700, y: 180, department: Department.SPARE_SALES, details: ['청구자료 준비', '대금지급 확인'] },
    ],
    edges: [
      { from: 'ss_1', to: 'ss_2', isAnimated: true },
      { from: 'ss_2', to: 'ss_dec1' },
      { from: 'ss_dec1', to: 'ss_3', label: 'YES' },
      { from: 'ss_3', to: 'ss_4', isAnimated: true },
      { from: 'ss_5', to: 'ss_6', isAnimated: true },
      { from: 'ss_6', to: 'ss_7', isAnimated: true },
      { from: 'ss_7', to: 'ss_8', isAnimated: true },
    ]
  },
  [Department.SPARE_LOGISTICS]: {
    nodes: [
      { id: 'sl_1', label: '수주 ERP 등록', type: 'input', x: 50, y: 100, department: Department.SPARE_LOGISTICS },
      { id: 'sl_2', label: '제품 준비 확인', type: 'process', x: 250, y: 100, department: Department.SPARE_LOGISTICS },
      { id: 'sl_3', label: '시방 완료 여부', type: 'decision', x: 450, y: 100, department: Department.SPARE_LOGISTICS },
      { id: 'sl_4', label: '자재 입고/진행', type: 'process', x: 650, y: 100, department: Department.SPARE_LOGISTICS },
      { id: 'sl_5', label: '생산완료 확인', type: 'system', x: 850, y: 100, department: Department.SPARE_LOGISTICS },
      { id: 'sl_6', label: '포장/납품 서류', type: 'process', x: 1050, y: 100, department: Department.SPARE_LOGISTICS, details: ['INVOICE/DN 작성', 'AWB 발행'] },
      { id: 'sl_7', label: '출고 완료', type: 'output', x: 1250, y: 100, department: Department.SPARE_LOGISTICS },
    ],
    edges: [
      { from: 'sl_1', to: 'sl_2', isAnimated: true },
      { from: 'sl_2', to: 'sl_3' },
      { from: 'sl_3', to: 'sl_4', label: '완료' },
      { from: 'sl_4', to: 'sl_5', isAnimated: true },
      { from: 'sl_5', to: 'sl_6', isAnimated: true },
      { from: 'sl_6', to: 'sl_7', isAnimated: true },
    ]
  },
  [Department.OPERATION_INNOVATION]: {
    nodes: [
      { id: 'oi_1', label: 'MRO 수주 확인', type: 'input', x: 50, y: 100, department: Department.OPERATION_INNOVATION },
      { id: 'oi_2', label: '생산/입고 파악', type: 'process', x: 250, y: 100, department: Department.OPERATION_INNOVATION, details: ['Level3000 생산현황'] },
      { id: 'oi_3', label: '자재 불출 요청', type: 'process', x: 450, y: 100, department: Department.OPERATION_INNOVATION },
      { id: 'oi_4', label: '엔지니어 배정', type: 'process', x: 650, y: 100, department: Department.OPERATION_INNOVATION, details: ['출장 일정 조율'] },
      { id: 'oi_5', label: 'CBT/IBT 생성', type: 'system', x: 850, y: 100, department: Department.OPERATION_INNOVATION, details: ['E-Learning 계정 생성'] },
      { id: 'oi_6', label: '서비스 완료/정산', type: 'output', x: 1050, y: 100, department: Department.OPERATION_INNOVATION },
    ],
    edges: [
      { from: 'oi_1', to: 'oi_2', isAnimated: true },
      { from: 'oi_2', to: 'oi_3', isAnimated: true },
      { from: 'oi_3', to: 'oi_4', isAnimated: true },
      { from: 'oi_4', to: 'oi_5', isAnimated: true },
      { from: 'oi_5', to: 'oi_6', isAnimated: true },
    ]
  }
};
